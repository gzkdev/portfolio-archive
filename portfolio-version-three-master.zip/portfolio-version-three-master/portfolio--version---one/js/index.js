// UTILITY javascript
let nav = document.querySelector('.nav');
let menu = document.querySelector('.menu');
let navItems = document.querySelectorAll('.nav__item')
let navLink = document.querySelector('.nav__link')
let menuBars = document.querySelectorAll('.bar');

window.addEventListener('scroll', () => {
    let header = document.querySelector('.header');
    header.classList.toggle('sticky', window.scrollY > 0);
})

menu.addEventListener('click', () => {
    nav.classList.toggle('open');
    menuBars.forEach(item => {
        item.classList.toggle('active');
    })
})

navItems.forEach(item => {
    item.addEventListener('click', () => {
        // check if the open class is active on each item
        if (nav.classList.toggle('open') === true) {
            nav.classList.toggle('open');
        }
        menuBars.forEach(item =>{
            item.classList.toggle('active');
        })
    })
})

