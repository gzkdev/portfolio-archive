export const routeLinks = [
    {
        path: "/",
        text: "Home"
    },
    {
        path: "/projects",
        text: "Projects"
    },
    {
        path: "/about",
        text: "About"
    },
    {
        path: "/contact",
        text: "Contact"
    }]
