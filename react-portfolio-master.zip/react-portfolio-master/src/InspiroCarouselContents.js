import Img01 from './assets/images/four.jpg'
import Img02 from './assets/images/three.png'
import Img03 from './assets/images/six.png'
import Img04 from './assets/images/five.png'
import Img05 from './assets/images/seven.png'
import Img06 from './assets/images/ten.png'
import Img07 from './assets/images/nine.png'
import Img08 from './assets/images/two.jpg'

const InspiroItems = [{
    image: Img06,
    link: "/projects/1",
    id: 1

},
{
    image: Img02,
    link: "/projects/1",
    id: 2

},
{
    image: Img05,
    link: "/projects/1",
    id: 3

},
{
    image: Img03,
    link: "/projects/1",
    id: 4

}, {
    image: Img01,
    link: "/projects/1",
    id: 1

},
{
    image: Img07,
    link: "/projects/1",
    id: 2

},
{
    image: Img04,
    link: "/projects/1",
    id: 3

},
{
    image: Img03,
    link: "/projects/1",
    id: 4

}, {
    image: Img01,
    link: "/projects/1",
    id: 1

},
{
    image: Img02,
    link: "/projects/1",
    id: 2

},
{
    image: Img04,
    link: "/projects/1",
    id: 3

},
{
    image: Img08,
    link: "/projects/1",
    id: 4

}]


export default InspiroItems;