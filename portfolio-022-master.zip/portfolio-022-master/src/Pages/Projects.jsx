import React from "react";
import GoToTop from "../GotoTop";

function Projects() {
  GoToTop();
  return <div>Projects</div>;
}

export default Projects;
