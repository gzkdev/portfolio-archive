# 2022 Personal portfolio

My personal portfolio built with React and love to showcase my skills in 2022. I'm open to opportunities as a Front-end developer or JavaSccript engineer.
