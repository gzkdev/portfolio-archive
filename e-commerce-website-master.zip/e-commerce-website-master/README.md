# E-commerce webiste

An e-commerce website built with HTML, CSS and JavaScript
